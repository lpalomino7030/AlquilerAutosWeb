﻿using AlquilerAPI.Modelo;

namespace AlquilerAPI.Repositorio.Intefaces
{
    public interface IReporteAlquiler
    {
        List<ReporteAlquilerDTO> ReporteAlquileres();
    }
}
