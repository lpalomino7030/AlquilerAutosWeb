﻿namespace AlquilerAutos.Models
{
    public class EstadisticasAutosDTO
    {
        public Dictionary<string, int> DetalleEstados { get; set; } = new Dictionary<string, int>();
    }
}
